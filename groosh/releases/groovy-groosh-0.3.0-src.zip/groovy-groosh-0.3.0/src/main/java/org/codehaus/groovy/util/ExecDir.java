package org.codehaus.groovy.util;

import java.io.File;

public class ExecDir {
	private File dir;

	public void setDir(File dir) {
		this.dir = dir;
	}

	public File getDir() {
		return dir;
	}

}

package groovy.jms.provider;

import javax.jms.ConnectionFactory;

public interface JMSProvider {

    public ConnectionFactory getConnectionFactory();
}




//String.metaClass.debug = {-> "debug"}

println String.class.metaClass.hasMetaMethod('debug', null)
GroovyJMS

Homepage 
--------
http://docs.codehaus.org/display/GROOVY/GroovyJMS

Project structure
-----------------
 +- src		groovy source file, notice that it's in a flat structure, i.e. /src is the root, but not /src/groovy
 |
 +- test	test case(s)
 |
 +- lib		contains all depending jars for running the test cases
 

Until the project becomes more mature and provide a build file, you are recommended to import the project to your favorite IDE and run the test case(s). Intellij IDEA project files are included in the repository.

Dependency
----------
 - refer to lib/readme.txt

License
-------
This project adopts the same license as Groovy, refer to http://groovy.codehaus.org/faq.html#licence

Contact
-------
Please contact me at mingfai.ma (NO-SPAM-AT) gmail.com or the Groovy mail list for anything regarding this project.
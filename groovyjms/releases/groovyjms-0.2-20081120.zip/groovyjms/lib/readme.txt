
Logging
 - log4j-1.2.15.jar required
 	log4j will be removed soon!

ActiveMQ and dependency
 - activemq-all-5.3-SNAPSHOT.jar required.
 	if you don't use ActiveMQ, you need to provide the JMS API library
 - commons-logging-1.1.1.jar
 
 
Optional: activemq pool
 - commons-pool
 - generonimo-jta*.jar